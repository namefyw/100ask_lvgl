# Overview

[esp_freetype](https://github.com/100askTeam/esp_freetype) is an out of the box [ESP-IDF component](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-guides/build-system.html#component-cmakelists-files) that is as convenient and simple as regular ESP-IDF components, and you can import it into your project for use.

# Examples

You can obtain corresponding usage examples in the example directory.

# Forum

[https://forums.100ask.net](https://forums.100ask.net)
