# 说明

[esp_freetype](https://github.com/100askTeam/esp_freetype) 是一个开箱即用的 [ESP-IDF 组件](https://docs.espressif.com/projects/esp-idf/zh_CN/latest/esp32/api-guides/build-system.html#component-directories)，和常规的 ESP-IDF 组件那样方便简单，你可以将其导入到你的项目工程中使用。

# 使用示例

你可以在 `example` 目录中获取相应的使用示例。

# 技术交流

如果你在使用过程中遇到问题需要帮助，可以发起 issue 或者在技术社区留言： [https://forums.100ask.net](https://forums.100ask.net)。